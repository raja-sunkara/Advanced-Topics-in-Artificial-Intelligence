# The MNIST-1D dataset | 2020
# Sam Greydanus

import time, copy
import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

from .utils import ObjectView

def get_model_args(as_dict=False):
  arg_dict = {'input_size': 40,
          'output_size': 10,
          'hidden_size': 1000,
          'learning_rate': 1e-2,
          'weight_decay': 0,
          'batch_size': 100,
          'total_steps': 8000,
          'print_every': 1000,
          'eval_every': 250,
          'checkpoint_every': 1000,
          'device': 'cpu',
          'seed': 42}
  return arg_dict if as_dict else ObjectView(arg_dict)


def accuracy(model, inputs, targets):
  preds = model(inputs).argmax(-1).cpu().numpy()
  targets=torch.argmax(targets, dim=1)
  targets = targets.cpu().numpy().astype(np.float32)

#  print(preds[0])
#  print(targets[0])
  return 100*sum(preds==targets)/len(targets)


def train_model(train_X, train_Y, test_X, test_Y, model, args):
#  criterion = nn.CrossEntropyLoss()
  criterion = nn.MSELoss()
  

#  optimizer = optim.Adam(model.parameters(), args.learning_rate, weight_decay=args.weight_decay)
  optimizer = optim.SGD(model.parameters(),1e-3)

  x_train, x_test = torch.Tensor(train_X), torch.Tensor(test_X)
  y_train, y_test = torch.Tensor(train_Y), torch.Tensor(test_Y)

#  print("before one hot encoding",y_train.shape)
  #print(y_train)
  y_train = F.one_hot(y_train.to(torch.int64),num_classes=10)
  y_test = F.one_hot(y_test.to(torch.int64),num_classes=10)
#  print("After oen hot encoding",y_train.shape)

  model = model.to(args.device)
  x_train, x_test, y_train, y_test = [v.to(args.device) for v in [x_train, x_test, y_train, y_test]]

  results = {'checkpoints':[], 'train_losses':[], 'test_losses':[],'train_acc':[],'test_acc':[]}
  t0 = time.time()
  for step in range(args.total_steps+1):
      bix = (step*args.batch_size)%len(x_train) # batch index
      x, y = x_train[bix:bix+args.batch_size], y_train[bix:bix+args.batch_size]

#      print("mdodel output shape",model(x).shape)
#      print(y)
#      print("ground truth shape", y.shape)
      
      loss = criterion(model(x), y.float())
#      print(x)
#      print(y.float())
#      print(model(x))
      results['train_losses'].append(loss.item())
      loss.backward() ; optimizer.step() ; optimizer.zero_grad()

      if args.eval_every > 0 and step % args.eval_every == 0: # evaluate the model
          test_loss = criterion(model(x_test), y_test.float())
          results['test_losses'].append(test_loss.item())
          results['train_acc'].append(accuracy(model, x_train, y_train))
          results['test_acc'].append(accuracy(model, x_test, y_test))

      if step > 0 and step % args.print_every == 0: # print out training progress
          t1 = time.time()
          print("step {}, dt {:.2f}s, train_loss {:.3e}, test_loss {:.3e}, train_acc {:.1f}, test_acc {:.1f}"
              .format(step, t1-t0, loss.item(), results['test_losses'][-1], \
                      results['train_acc'][-1], results['test_acc'][-1]))
          t0 = t1

      if args.checkpoint_every > 0 and step % args.checkpoint_every == 0: # save model checkpoints
          model.step = step
          results['checkpoints'].append( copy.deepcopy(model) )

      if step%100==0:
        print("Training completed for {} steps".format(step))
  return results




def train_model2(train_X, train_Y, test_X, test_Y, model, args):
#  criterion = nn.CrossEntropyLoss()
  criterion = nn.MSELoss()
  

#  optimizer = optim.Adam(model.parameters(), args.learning_rate, weight_decay=args.weight_decay)
  optimizer = optim.SGD(model.parameters(),1e-3)

  x_train, x_test = torch.Tensor(train_X), torch.Tensor(test_X)
  y_train, y_test = torch.Tensor(train_Y), torch.Tensor(test_Y)

#  print("before one hot encoding",y_train.shape)
  #print(y_train)
  y_train = F.one_hot(y_train.to(torch.int64),num_classes=10)
  y_test = F.one_hot(y_test.to(torch.int64),num_classes=10)
#  print("After oen hot encoding",y_train.shape)

  model = model.to(args.device)
  x_train, x_test, y_train, y_test = [v.to(args.device) for v in [x_train, x_test, y_train, y_test]]

  results = {'checkpoints':[], 'train_losses':[], 'test_losses':[],'train_acc':[],'test_acc':[]}
  t0 = time.time()
  for step in range(args.total_steps+1):


      index_integer = step//1000
#      print(index_integer)
      label_list = list(range(index_integer+1))
#      print(label_list)

      y=np.argmax(y_train,axis=1)
      
      result = y.apply_(lambda x: x in label_list).bool()
#      print(result)

      
      x, y = x_train[result], y_train[result]
#      print(x.shape,y.shape)
      loss = criterion(model(x), y.float())
#      print(x)
#      print(y.float())
#      print(model(x))
      results['train_losses'].append(loss.item())
      loss.backward() ; optimizer.step() ; optimizer.zero_grad()

      if args.eval_every > 0 and step % args.eval_every == 0: # evaluate the model
          test_loss = criterion(model(x_test), y_test.float())
          results['test_losses'].append(test_loss.item())
          results['train_acc'].append(accuracy(model, x_train, y_train))
          results['test_acc'].append(accuracy(model, x_test, y_test))

      if step > 0 and step % args.print_every == 0: # print out training progress
          t1 = time.time()
          print("step {}, dt {:.2f}s, train_loss {:.3e}, test_loss {:.3e}, train_acc {:.1f}, test_acc {:.1f}"
              .format(step, t1-t0, loss.item(), results['test_losses'][-1], \
                      results['train_acc'][-1], results['test_acc'][-1]))
          t0 = t1

      if args.checkpoint_every > 0 and step % args.checkpoint_every == 0: # save model checkpoints
          model.step = step
          results['checkpoints'].append( copy.deepcopy(model) )

      if step%100==0:
        print("Training completed for {} steps".format(step))
  return results